# Algo-lib (the Algorithm Library)

This is a simple example package. It contains two searching algorithms. The purpose of this repo is to practice packaging a library for distribution. 